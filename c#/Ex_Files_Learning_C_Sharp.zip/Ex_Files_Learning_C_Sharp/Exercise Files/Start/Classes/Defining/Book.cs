using System;

namespace Defining
{
    // classes have a name, unique within the namespace
    public class Book
    {
        // TODO: classes have member variables, or "fields" to hold data


        // TODO: classes have one or more constructors


        // TODO: methods are used to operate on the class and data

    }
}
