﻿using System;

namespace Defining
{
    class Program
    {
        static void Main(string[] args)
        {
            // TODO: Create new object instances using the "new" operator

            
            // TODO: Call a method on the object


            // TODO: try to set one of the properties -- 
            // this will result in an error

        }
    }
}
