﻿using System;

// Functions are used to group re-usable code together in a single
// unit that can be customized with parameters.

// TODO: Functions have a return type, name, and optional parameters


// TODO: A function with no return value has a 'void' type


// TODO: Call first function


// TODO: Call second function

