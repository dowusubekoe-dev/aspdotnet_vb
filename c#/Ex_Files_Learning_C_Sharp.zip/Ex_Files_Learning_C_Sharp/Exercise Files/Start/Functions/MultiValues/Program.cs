﻿using System;

namespace MultiValues
{
    class Program
    {
        static void Main(string[] args)
        {
            // TODO: Tuples are grouped values added in C# 7


            // TODO: Tuple values are mutable


            // TODO: Functions can work with tuples

        }

        // TODO: Functions can return multiple values using tuples

    }
}
