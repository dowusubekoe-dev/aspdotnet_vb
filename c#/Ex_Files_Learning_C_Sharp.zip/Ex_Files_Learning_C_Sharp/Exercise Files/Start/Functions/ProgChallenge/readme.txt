Use this folder for the Programming Challenge.

Create a new .NET console app by running the command:

dotnet new console

In your terminal in this folder.
