﻿using System;

namespace Comments
{
    class Program
    {
        /// XML Comments are used to help provide documentation
        /// They start with triple-slashes and have a special syntax
        static void Main(string[] args)
        {

            Console.WriteLine("Hello World!");

        }
    }
}
