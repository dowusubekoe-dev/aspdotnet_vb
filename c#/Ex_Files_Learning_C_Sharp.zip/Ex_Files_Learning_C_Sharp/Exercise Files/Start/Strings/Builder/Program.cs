﻿using System;
using System.Text;

namespace Builder
{
    class Program
    {
        static void Main(string[] args)
        {
            int jumpCount = 10;
            string[] animals = {"goats", "cats", "pigs"};

            // TODO: create a StringBuilder

            
            // TODO: print some basic stats about the StringBuilder


            // TODO: Add some strings to the builder using Append


            // TODO: AppendLine can append a line ending


            // TODO: AppendFormat can be used to append formatted strings


            // TODO: AppendJoin can iterate over a set of values


            // TODO: Modify the content using Replace


            // TODO: Insert content at any index

            
            // TODO: Convert to a single string

        }
    }
}
